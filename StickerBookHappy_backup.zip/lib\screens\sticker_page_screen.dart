import 'package:flutter/material.dart';
import '../models/sticker_model.dart';
import '../widgets/animated_builder.dart';
import '../widgets/draggable_sticker.dart';
import '../widgets/sticker_target.dart';

class StickerPageScreen extends StatefulWidget {
  final StickerPage page;

  const StickerPageScreen({super.key, required this.page});

  @override
  State<StickerPageScreen> createState() => _StickerPageScreenState();
}

class _StickerPageScreenState extends State<StickerPageScreen>
    with TickerProviderStateMixin {
  late List<StickerItem> _stickers;
  late AnimationController _completionController;
  late Animation<double> _completionAnimation;
  bool _isComplete = false;

  @override
  void initState() {
    super.initState();
    _stickers = widget.page.stickers
        .map((s) => StickerItem(
              id: s.id,
              emoji: s.emoji,
              name: s.name,
              targetX: s.targetX,
              targetY: s.targetY,
              size: s.size,
            ))
        .toList();
    _stickers.shuffle();

    _completionController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _completionAnimation = CurvedAnimation(
      parent: _completionController,
      curve: Curves.elasticOut,
    );
  }

  @override
  void dispose() {
    _completionController.dispose();
    super.dispose();
  }

  void _onStickerPlaced(String stickerId) {
    setState(() {
      final index = _stickers.indexWhere((s) => s.id == stickerId);
      if (index != -1) {
        _stickers[index] = _stickers[index].copyWith(isPlaced: true);
      }
      if (_stickers.every((s) => s.isPlaced)) {
        _isComplete = true;
        _completionController.forward();
      }
    });
  }

  void _resetPage() {
    setState(() {
      _stickers = _stickers.map((s) => s.copyWith(isPlaced: false)).toList();
      _stickers.shuffle();
      _isComplete = false;
      _completionController.reset();
    });
  }

  @override
  Widget build(BuildContext context) {
    final unplacedStickers = _stickers.where((s) => !s.isPlaced).toList();
    final placedCount = _stickers.where((s) => s.isPlaced).length;

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              widget.page.gradientColors.first.withValues(alpha: 0.3),
              widget.page.gradientColors.last.withValues(alpha: 0.1),
              Colors.white,
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Top bar
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Row(
                  children: [
                    _buildBackButton(context),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            widget.page.title,
                            style: const TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                              color: Color(0xFF1A237E),
                            ),
                          ),
                          Text(
                            '$placedCount / ${_stickers.length} placed',
                            style: TextStyle(
                              fontSize: 13,
                              color: Colors.grey.shade600,
                            ),
                          ),
                        ],
                      ),
                    ),
                    _buildProgressRing(placedCount),
                    const SizedBox(width: 8),
                    IconButton(
                      onPressed: _resetPage,
                      icon: const Icon(Icons.refresh_rounded),
                      tooltip: 'Reset',
                      style: IconButton.styleFrom(
                        backgroundColor: Colors.grey.shade200,
                      ),
                    ),
                  ],
                ),
              ),
              // Sticker placement area - use LayoutBuilder here at Stack level
              Expanded(
                flex: 3,
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(
                      color: widget.page.gradientColors.first.withValues(alpha: 0.3),
                      width: 2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.05),
                        blurRadius: 20,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(22),
                    child: LayoutBuilder(
                      builder: (context, constraints) {
                        return Stack(
                          children: [
                            _buildBackgroundPattern(),
                            ..._stickers.map((sticker) {
                              final targetSize = sticker.size;
                              final left = sticker.targetX * (constraints.maxWidth - targetSize);
                              final top = sticker.targetY * (constraints.maxHeight - targetSize);
                              return Positioned(
                                left: left,
                                top: top,
                                child: StickerTarget(
                                  sticker: sticker,
                                  onAccepted: _onStickerPlaced,
                                  accentColor: widget.page.gradientColors.first,
                                ),
                              );
                            }),
                            if (_isComplete) _buildCompletionOverlay(),
                          ],
                        );
                      },
                    ),
                  ),
                ),
              ),
              // Sticker tray
              Container(
                height: 130,
                margin: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.08),
                      blurRadius: 15,
                      offset: const Offset(0, -2),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Text(
                        unplacedStickers.isEmpty
                            ? '🎉 All done!'
                            : '👆 Drag stickers to their spots',
                        style: TextStyle(
                          fontSize: 13,
                          color: Colors.grey.shade600,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Expanded(
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        itemCount: unplacedStickers.length,
                        itemBuilder: (context, index) {
                          return DraggableSticker(
                            sticker: unplacedStickers[index],
                            accentColor: widget.page.gradientColors.first,
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBackButton(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.pop(context),
      child: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.08),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: const Icon(
          Icons.arrow_back_ios_new_rounded,
          size: 20,
          color: Color(0xFF1A237E),
        ),
      ),
    );
  }

  Widget _buildProgressRing(int placedCount) {
    return SizedBox(
      width: 44,
      height: 44,
      child: Stack(
        alignment: Alignment.center,
        children: [
          CircularProgressIndicator(
            value: placedCount / _stickers.length,
            strokeWidth: 4,
            backgroundColor: Colors.grey.shade200,
            color: widget.page.gradientColors.first,
          ),
          Text(
            '${(placedCount / _stickers.length * 100).toInt()}%',
            style: const TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.bold,
              color: Color(0xFF1A237E),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBackgroundPattern() {
    return Opacity(
      opacity: 0.04,
      child: GridView.count(
        physics: const NeverScrollableScrollPhysics(),
        crossAxisCount: 5,
        children: List.generate(25, (i) {
          return Center(
            child: Text(
              widget.page.backgroundEmoji,
              style: const TextStyle(fontSize: 28),
            ),
          );
        }),
      ),
    );
  }

  Widget _buildCompletionOverlay() {
    return StickerAnimatedBuilder(
      animation: _completionAnimation,
      builder: (context, child) {
        final value = _completionAnimation.value;
        return Container(
          color: Colors.black.withValues(alpha: 0.3 * value),
          child: Center(
            child: Transform.scale(
              scale: value,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(24),
                  boxShadow: [
                    BoxShadow(
                      color: widget.page.gradientColors.first.withValues(alpha: 0.3),
                      blurRadius: 30,
                      spreadRadius: 5,
                    ),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text('🎉', style: TextStyle(fontSize: 48)),
                    const SizedBox(height: 8),
                    const Text(
                      'Awesome!',
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF1A237E),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'All stickers placed!',
                      style: TextStyle(
                        fontSize: 15,
                        color: Colors.grey.shade600,
                      ),
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton.icon(
                      onPressed: _resetPage,
                      icon: const Icon(Icons.refresh_rounded),
                      label: const Text('Play Again'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: widget.page.gradientColors.first,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 24,
                          vertical: 12,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
