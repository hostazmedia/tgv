import 'package:flutter/material.dart';
import '../models/sticker_model.dart';
import 'animated_builder.dart';

class StickerTarget extends StatefulWidget {
  final StickerItem sticker;
  final Function(String) onAccepted;
  final Color accentColor;

  const StickerTarget({
    super.key,
    required this.sticker,
    required this.onAccepted,
    required this.accentColor,
  });

  @override
  State<StickerTarget> createState() => _StickerTargetState();
}

class _StickerTargetState extends State<StickerTarget>
    with SingleTickerProviderStateMixin {
  bool _isHovering = false;
  late AnimationController _bounceController;
  late Animation<double> _bounceAnimation;

  @override
  void initState() {
    super.initState();
    _bounceController = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    _bounceAnimation = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 0.0, end: 1.3), weight: 40),
      TweenSequenceItem(tween: Tween(begin: 1.3, end: 0.9), weight: 25),
      TweenSequenceItem(tween: Tween(begin: 0.9, end: 1.05), weight: 20),
      TweenSequenceItem(tween: Tween(begin: 1.05, end: 1.0), weight: 15),
    ]).animate(CurvedAnimation(
      parent: _bounceController,
      curve: Curves.easeInOut,
    ));
  }

  @override
  void dispose() {
    _bounceController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // No LayoutBuilder or Positioned here - parent handles positioning
    return DragTarget<String>(
      onWillAcceptWithDetails: (details) {
        final willAccept = details.data == widget.sticker.id;
        if (willAccept && !_isHovering) {
          setState(() => _isHovering = true);
        }
        return willAccept;
      },
      onLeave: (_) {
        setState(() => _isHovering = false);
      },
      onAcceptWithDetails: (details) {
        setState(() => _isHovering = false);
        _bounceController.forward(from: 0);
        widget.onAccepted(details.data);
      },
      builder: (context, candidateData, rejectedData) {
        if (widget.sticker.isPlaced) {
          return _buildPlacedSticker();
        }
        return _buildTargetSlot();
      },
    );
  }

  Widget _buildPlacedSticker() {
    return StickerAnimatedBuilder(
      animation: _bounceAnimation,
      builder: (context, child) {
        return Transform.scale(
          scale: _bounceController.isAnimating ? _bounceAnimation.value : 1.0,
          child: child,
        );
      },
      child: SizedBox(
        width: widget.sticker.size,
        height: widget.sticker.size,
        child: Center(
          child: Text(
            widget.sticker.emoji,
            style: TextStyle(fontSize: widget.sticker.size * 0.6),
          ),
        ),
      ),
    );
  }

  Widget _buildTargetSlot() {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      width: widget.sticker.size,
      height: widget.sticker.size,
      decoration: BoxDecoration(
        color: _isHovering
            ? widget.accentColor.withValues(alpha: 0.15)
            : Colors.grey.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: _isHovering
              ? widget.accentColor
              : Colors.grey.withValues(alpha: 0.25),
          width: _isHovering ? 2.5 : 1.5,
          strokeAlign: BorderSide.strokeAlignInside,
        ),
      ),
      child: Center(
        child: Opacity(
          opacity: _isHovering ? 0.5 : 0.15,
          child: Text(
            widget.sticker.emoji,
            style: TextStyle(fontSize: widget.sticker.size * 0.45),
          ),
        ),
      ),
    );
  }
}
