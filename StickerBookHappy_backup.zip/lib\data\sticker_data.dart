import 'package:flutter/material.dart';
import '../models/sticker_model.dart';

class StickerData {
  static List<StickerPage> getPages() {
    return [
      StickerPage(
        id: 'animals',
        title: 'Animals',
        subtitle: 'Farm & Wild Animals',
        backgroundEmoji: '🌿',
        gradientColors: [const Color(0xFF81C784), const Color(0xFF4CAF50)],
        stickers: [
          StickerItem(id: 'cat', emoji: '🐱', name: 'Cat', targetX: 0.15, targetY: 0.15, size: 65),
          StickerItem(id: 'dog', emoji: '🐶', name: 'Dog', targetX: 0.55, targetY: 0.12, size: 65),
          StickerItem(id: 'cow', emoji: '🐮', name: 'Cow', targetX: 0.35, targetY: 0.35, size: 70),
          StickerItem(id: 'pig', emoji: '🐷', name: 'Pig', targetX: 0.7, targetY: 0.38, size: 60),
          StickerItem(id: 'chicken', emoji: '🐔', name: 'Chicken', targetX: 0.1, targetY: 0.55, size: 55),
          StickerItem(id: 'horse', emoji: '🐴', name: 'Horse', targetX: 0.5, targetY: 0.6, size: 70),
        ],
      ),
      StickerPage(
        id: 'fruits',
        title: 'Fruits',
        subtitle: 'Yummy Fruits',
        backgroundEmoji: '🍽️',
        gradientColors: [const Color(0xFFFFB74D), const Color(0xFFFF9800)],
        stickers: [
          StickerItem(id: 'apple', emoji: '🍎', name: 'Apple', targetX: 0.2, targetY: 0.12, size: 60),
          StickerItem(id: 'banana', emoji: '🍌', name: 'Banana', targetX: 0.6, targetY: 0.15, size: 65),
          StickerItem(id: 'grape', emoji: '🍇', name: 'Grape', targetX: 0.15, targetY: 0.4, size: 60),
          StickerItem(id: 'watermelon', emoji: '🍉', name: 'Watermelon', targetX: 0.55, targetY: 0.42, size: 70),
          StickerItem(id: 'strawberry', emoji: '🍓', name: 'Strawberry', targetX: 0.35, targetY: 0.65, size: 55),
          StickerItem(id: 'orange', emoji: '🍊', name: 'Orange', targetX: 0.7, targetY: 0.62, size: 60),
        ],
      ),
      StickerPage(
        id: 'vehicles',
        title: 'Vehicles',
        subtitle: 'Cars & Transport',
        backgroundEmoji: '🛣️',
        gradientColors: [const Color(0xFF64B5F6), const Color(0xFF2196F3)],
        stickers: [
          StickerItem(id: 'car', emoji: '🚗', name: 'Car', targetX: 0.15, targetY: 0.15, size: 65),
          StickerItem(id: 'bus', emoji: '🚌', name: 'Bus', targetX: 0.6, targetY: 0.12, size: 70),
          StickerItem(id: 'airplane', emoji: '✈️', name: 'Airplane', targetX: 0.35, targetY: 0.38, size: 70),
          StickerItem(id: 'ship', emoji: '🚢', name: 'Ship', targetX: 0.7, targetY: 0.4, size: 65),
          StickerItem(id: 'bicycle', emoji: '🚲', name: 'Bicycle', targetX: 0.12, targetY: 0.6, size: 60),
          StickerItem(id: 'helicopter', emoji: '🚁', name: 'Helicopter', targetX: 0.55, targetY: 0.62, size: 65),
        ],
      ),
      StickerPage(
        id: 'food',
        title: 'Food',
        subtitle: 'Delicious Food',
        backgroundEmoji: '🍴',
        gradientColors: [const Color(0xFFE57373), const Color(0xFFF44336)],
        stickers: [
          StickerItem(id: 'pizza', emoji: '🍕', name: 'Pizza', targetX: 0.2, targetY: 0.15, size: 70),
          StickerItem(id: 'burger', emoji: '🍔', name: 'Burger', targetX: 0.65, targetY: 0.12, size: 65),
          StickerItem(id: 'icecream', emoji: '🍦', name: 'Ice Cream', targetX: 0.15, targetY: 0.42, size: 60),
          StickerItem(id: 'cake', emoji: '🎂', name: 'Cake', targetX: 0.55, targetY: 0.4, size: 65),
          StickerItem(id: 'donut', emoji: '🍩', name: 'Donut', targetX: 0.35, targetY: 0.65, size: 55),
          StickerItem(id: 'cookie', emoji: '🍪', name: 'Cookie', targetX: 0.72, targetY: 0.63, size: 55),
        ],
      ),
    ];
  }
}
