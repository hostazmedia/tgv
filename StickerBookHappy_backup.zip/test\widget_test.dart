import 'package:flutter_test/flutter_test.dart';
import 'package:sticker_book_happy/main.dart';

void main() {
  testWidgets('App loads successfully', (WidgetTester tester) async {
    await tester.pumpWidget(const StickerBookApp());
    expect(find.text('Sticker Book'), findsOneWidget);
  });
}
