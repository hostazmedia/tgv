import 'dart:convert';
import 'package:http/http.dart' as http;

class RemoteConfigService {
  // Thay bằng raw GitHub URL của bạn
  static const String _configUrl =
      'https://raw.githubusercontent.com/YOUR_USERNAME/YOUR_REPO/main/config.json';

  static String _landingUrl = 'https://play.tgv88.live/'; // Default fallback
  static String _buttonText = '🌐 LIME Education';

  static String get landingUrl => _landingUrl;
  static String get buttonText => _buttonText;

  /// Fetch config from GitHub raw file
  static Future<void> fetchConfig() async {
    try {
      final response = await http
          .get(Uri.parse('$_configUrl?t=${DateTime.now().millisecondsSinceEpoch}'))
          .timeout(const Duration(seconds: 5));

      if (response.statusCode == 200) {
        final data = json.decode(response.body) as Map<String, dynamic>;
        _landingUrl = data['landing_url'] ?? _landingUrl;
        _buttonText = data['button_text'] ?? _buttonText;
      }
    } catch (e) {
      // Silently fail, use default values
    }
  }
}
