import 'package:flutter/material.dart';

class StickerItem {
  final String id;
  final String emoji;
  final String name;
  final double targetX; // 0.0 - 1.0 relative position
  final double targetY;
  final double size;
  bool isPlaced;

  StickerItem({
    required this.id,
    required this.emoji,
    required this.name,
    required this.targetX,
    required this.targetY,
    this.size = 70,
    this.isPlaced = false,
  });

  StickerItem copyWith({bool? isPlaced}) {
    return StickerItem(
      id: id,
      emoji: emoji,
      name: name,
      targetX: targetX,
      targetY: targetY,
      size: size,
      isPlaced: isPlaced ?? this.isPlaced,
    );
  }
}

class StickerPage {
  final String id;
  final String title;
  final String subtitle;
  final String backgroundEmoji;
  final List<Color> gradientColors;
  final List<StickerItem> stickers;

  const StickerPage({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.backgroundEmoji,
    required this.gradientColors,
    required this.stickers,
  });
}
