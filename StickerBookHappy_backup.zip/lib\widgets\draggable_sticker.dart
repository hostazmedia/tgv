import 'package:flutter/material.dart';
import '../models/sticker_model.dart';

class DraggableSticker extends StatelessWidget {
  final StickerItem sticker;
  final Color accentColor;

  const DraggableSticker({
    super.key,
    required this.sticker,
    required this.accentColor,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
      child: Draggable<String>(
        data: sticker.id,
        feedback: Material(
          color: Colors.transparent,
          child: _buildStickerVisual(isDragging: true),
        ),
        childWhenDragging: Opacity(
          opacity: 0.3,
          child: _buildStickerVisual(),
        ),
        child: _buildStickerVisual(),
      ),
    );
  }

  Widget _buildStickerVisual({bool isDragging = false}) {
    return Container(
      width: 80,
      height: 90,
      decoration: BoxDecoration(
        color: isDragging
            ? accentColor.withValues(alpha: 0.15)
            : Colors.grey.shade50,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isDragging ? accentColor : Colors.grey.shade200,
          width: isDragging ? 2.5 : 1.5,
        ),
        boxShadow: isDragging
            ? [
                BoxShadow(
                  color: accentColor.withValues(alpha: 0.3),
                  blurRadius: 16,
                  offset: const Offset(0, 6),
                ),
              ]
            : [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.05),
                  blurRadius: 4,
                  offset: const Offset(0, 2),
                ),
              ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            sticker.emoji,
            style: TextStyle(fontSize: isDragging ? 38 : 34),
          ),
          const SizedBox(height: 2),
          Text(
            sticker.name,
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w600,
              color: isDragging ? accentColor : Colors.grey.shade700,
            ),
          ),
        ],
      ),
    );
  }
}
