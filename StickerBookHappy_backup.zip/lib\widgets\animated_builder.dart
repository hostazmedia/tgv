import 'package:flutter/material.dart';

/// Custom AnimatedBuilder widget since Flutter's built-in AnimatedBuilder
/// has a different API. This wraps AnimatedWidget for convenience.
class StickerAnimatedBuilder extends AnimatedWidget {
  final Widget Function(BuildContext, Widget?) builder;
  final Widget? child;

  const StickerAnimatedBuilder({
    super.key,
    required Animation<double> animation,
    required this.builder,
    this.child,
  }) : super(listenable: animation);

  @override
  Widget build(BuildContext context) {
    return builder(context, child);
  }
}
